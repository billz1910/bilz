





!#/bin/bash
#VARIABLE
clear
blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'


echo -e "$red░█████╗░████████╗████████╗░█████╗░░█████╗░██╗░░██╗"
echo -e "$red██╔══██╗╚══██╔══╝╚══██╔══╝██╔══██╗██╔══██╗██║░██╔╝"
echo -e "$red███████║░░░██║░░░░░░██║░░░███████║██║░░╚═╝█████═╝░"
echo -e "$red██╔══██║░░░██║░░░░░░██║░░░██╔══██║██║░░██╗██╔═██╗░"
echo -e "$red██║░░██║░░░██║░░░░░░██║░░░██║░░██║╚█████╔╝██║░╚██╗"
echo -e "$red╚═╝░░╚═╝░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░╚═╝░░╚═╝"

echo -e "$white░██╗░░░░░░░██╗███████╗██████╗░"
echo -e "$white░██║░░██╗░░██║██╔════╝██╔══██╗"
echo -e "$white░╚██╗████╗██╔╝█████╗░░██████╦╝"
echo -e "$white░░████╔═████║░██╔══╝░░██╔══██╗"
echo -e "$white░░╚██╔╝░╚██╔╝░███████╗██████╦╝"
echo -e "$white░░░╚═╝░░░╚═╝░░╚══════╝╚═════╝░"
echo -e ""
echo -e "$red[$green~$red] Author :$white DIMAX66"
echo -e "$red[$green~$red] Team :$white PADANG SYSTEM ERROR"
echo -e "$red[$green~$red] Tools :$white ATTACKER WEB"
echo -e "$red[$green~$red] Telegram :$white https://t.me/PadangSystemError"
echo -e "$red[$green~$red] github :$white https://github.com/EscobarPadang"
echo ""

echo -e "$red[$green 01 $red]$green CPANEL& WHM CHECKER"
echo -e "$red[$green 02 $red]$green LEAKED DATABASE"
echo -e "$red[$green 03 $red]$green WORDPRESS BRUTEFORCE,MULTI CMS AND JOMBLA"
echo -e "$red[$green 04 $red]$green AUTOEXPLOIT WP"
echo -e "$red[$green 05 $red]$green CHECKER LOGIN WORDPRESS"
echo -e "$red[$green 06 $red]$green PROXY CHECKER"
echo -e "$red[$green 07 $red]$green GET LARAVEL"
echo -e "$red[$green 08 $red]$green GET SMTP & CHECKER"
echo -e "$red[$green 09 $red]$green MASS GRABBER DOMAIN"
echo -e "$red[$green 10 $red]$green BRUTEFORCE MODV2 JOMBLA,OPENCART,WORDPRESS,DRUPAL,AND CMS"
echo -e "$red[$green 11 $red]$green SHELL FINDER"
echo -e "$red[$green 12 $red]$green SHELL CHECKER"
echo -e "$red[$green 13 $red]$green AUTO SQL INJECTION V2"
echo -e "$red[$green 14 $red]$green MASS CC CHECKER V1"
echo -e "$white"
read -p "MENU :" act;

if [ $act = 1 ] || [ $act = 01 ]
then
clear
sleep 3

cd asset
cd WH
apt install python
python cPanel.py

fi


if [ $act = 2 ] || [ $act = 02 ]
then
clear
sleep 3

cd asset
cd LK
apt install python
python dump.py

fi

if [ $act = 3 ] || [ $act = 03 ]
then
clear
sleep 3

cd asset
cd WP
apt install python
python multi.py

fi

if [ $act = 4 ] || [ $act = 04 ]   
then                                                              
clear
sleep 3                                    
cd asset
cd EX
apt install python
python exploit.py

fi

if [ $act = 5 ] || [ $act = 05 ]
then
clear
sleep 3
cd asset
cd SL
apt install python
python scanner.py

fi

if [ $act = 6 ] || [ $act = 06 ]
then
clear
sleep 3
cd asset
cd PC
apt install python
python proxy.py

fi

if [ $act = 7 ] || [ $act = 07 ]
then
clear
sleep 3
cd asset
cd LL
apt install python
python laravel.py

fi

if [ $act = 8 ] || [ $act = 08 ]
then
clear
sleep 3
cd asset
cd GS
apt install python
python GetSMTP.py

fi

if [ $act = 9 ] || [ $act = 09 ]
then
clear
sleep 3
cd asset
cd MD
apt install python
python main.py

fi

if [ $act = 10] || [ $act = 10 ]
then
clear
sleep 3
cd asset
cd SC
apt install python
python shell_checker.py

fi

if [ $act = 11 ] || [ $act = 11 ]
then
clear
sleep 3
cd asset
cd SF
apt install python
python SFind.py

fi

if [ $act = 12 ] || [ $act = 12 ]
then
clear
sleep 3
cd asset
cd AP
apt install python
pip install -r requirements.txt
python run.py

fi

if [ $act = 13 ] || [ $act = 13 ]
then
clear
sleep 3
cd asset
cd SQ
bash psqli.sh

fi

if [ $act = 14 ] || [ $act = 14 ]
then
clear
sleep 3
cd asset
cd JX
pkg install python
python JEXBrute.py

fi

if [ $act = 15 ] || [ $act = 15 ]
then
clear
sleep 3
cd asset
cd MG
pkg install python2
python2 massgrab.py

fi

if [ $act = 16 ] || [ $act = 16 ]
then
clear
sleep 3
cd asset
cd CC
pkg install python
pip install names
python cc.py

fi

if [ $act = 17 ] || [ $act = 17 ]
then
clear
sleep 3
cd asset
cd AE
pkg install python2
pip2 install requests
python2 AutoExploit.py

fi
